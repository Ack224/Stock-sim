export default function About() {
    return(
        <div>
            <h1>Strona o nas</h1>
            <p>Witaj w naszej aplikacji</p>
        </div>
    );
}