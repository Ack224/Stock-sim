export default function Home() {
    return(
        <div>
            <h1>Strona Głowna</h1>
            <p>Witaj w naszej aplikacji</p>
        </div>
    );
}