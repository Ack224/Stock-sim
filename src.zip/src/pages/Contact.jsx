export default function Contact() {
    return(
        <div>
            <h1>Strona Kontaktowa</h1>
            <p>Witaj w naszej aplikacji</p>
        </div>
    );
}