export default function AdminSettings() {
    return(
        <div>
            <input type="checkbox"/> Wycisz
            <input type="checkbox"/> włącz powiadomienia 
            
            
        </div>
    );
}